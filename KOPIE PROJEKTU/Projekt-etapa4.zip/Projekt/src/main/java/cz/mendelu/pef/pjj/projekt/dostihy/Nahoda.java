package cz.mendelu.pef.pjj.projekt.dostihy;

public class Nahoda {

}
