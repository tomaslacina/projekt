package cz.mendelu.pef.pjj.projekt.dostihy;

public class Figurka {

    Figurka(int pozice){
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    /**
     * Vrati poziciu figurky na plane.
     * @return pozicia figurky moze byt : 0,1,2,...40
     * @author xrepka
     * @version etapa-1
     */
    int getPoziceFigurky(){
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    /**
     * Nastavi novou pozici figurce.
     * @param posun - převezme hod z kostky (1-6) , nebo z akční karty (libovolné číslo)
     * @author xlacina5
     * @version etapa-1
     */
    void setPoziceFigurky(int posun){
        throw new UnsupportedOperationException("Not implemented yet.");
    }
}
