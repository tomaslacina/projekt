package cz.mendelu.pef.pjj.projekt.dostihy;

public class Kostka {
    Kostka(){
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    /**
     * Vrati hodnotu hodu.
     * @return hodnota hodu: 1,2,3,4,5,6
     * @author xrepka
     * @version etapa-1
     */
    int getHodnotaHodu(){
        throw new UnsupportedOperationException("Not implemented yet.");
    }



}
