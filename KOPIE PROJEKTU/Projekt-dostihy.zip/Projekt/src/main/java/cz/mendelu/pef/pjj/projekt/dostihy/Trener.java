package cz.mendelu.pef.pjj.projekt.dostihy;

public class Trener {


    Trener(){
        throw new UnsupportedOperationException("Not implemented  yet");
    }
}
