package cz.mendelu.pef.pjj.projekt.dostihy;

public class Policko {

    public Policko(){throw new UnsupportedOperationException("Not implemented yet");}

    /**
     * Zobrazí informace o daném políčku. Tyto informace budou čerpány ze souboru a podle čísla políčka se zobrazí tyto informace
     * hráči
     * @param cisloPolicka - mohou být hodnoty od 1-40
     * @author xlacina5
     * @version etapa-1
     */

    public void zobrazInformace(int cisloPolicka){
        throw new UnsupportedOperationException("Not implemented yet");
    }

    public int getCena(int cisloPolicka){
        throw new UnsupportedOperationException("Not implemented yet");
    }

}
